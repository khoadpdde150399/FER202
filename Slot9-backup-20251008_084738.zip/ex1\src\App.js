import 'bootstrap/dist/css/bootstrap.min.css';
import FooterPage from './pages/FooterPage';

function App() {
  return (
    <div>
      <FooterPage />
    </div>
  );
}

export default App;
